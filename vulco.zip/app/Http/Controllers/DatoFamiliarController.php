<?php

namespace App\Http\Controllers;

use App\Models\DatoFamiliar;
use Illuminate\Http\Request;

class DatoFamiliarController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function store()
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(DatoFamiliar $datoFamiliar)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DatoFamiliar $datoFamiliar)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, DatoFamiliar $datoFamiliar)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DatoFamiliar $datoFamiliar)
    {
        //
    }
}
