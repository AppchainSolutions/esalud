<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repository\ReligionRepository;


class ReligionController extends Controller
{
    protected $religionRepository;

    public function __construct(ReligionRepository $religionRepository)
    {
        $this->religionRepository = $religionRepository;
    }
    public function index()
    {
        return $this->religionRepository->all();
    }

    /**
     * Show the form for creating a new resource.
     */
        public function store()
    {
        //
    }


    /**
     * Display the specified resource.
     */
    public function all()
    {
        try {
            $query = ReligionModel::all();
            return response()->json([
                'result' => $query
            ]);
        } catch (QueryException $error) {
            Session::flash('message', 'No se encuentran registros.');

        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
