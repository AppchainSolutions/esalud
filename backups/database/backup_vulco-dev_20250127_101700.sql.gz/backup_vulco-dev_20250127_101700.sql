--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bateria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bateria (
    descripcion character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    id integer NOT NULL
);


ALTER TABLE public.bateria OWNER TO postgres;

--
-- Name: examen_epo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_epo (
    paciente_id integer NOT NULL,
    comentario text,
    fecha_realizacion date DEFAULT '1900-01-01'::date,
    fecha_recepcion date DEFAULT '1900-01-01'::date,
    fecha_solicitud date DEFAULT '1900-01-01'::date,
    fecha_vencimiento date DEFAULT '1900-01-01'::date,
    numero_solicitud integer,
    resultado character varying(255),
    tipo_examen integer,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    semaforo integer,
    estado_epo integer,
    id integer NOT NULL,
    bateria_id integer,
    codigo_verificacion integer
);


ALTER TABLE public.examen_epo OWNER TO postgres;

--
-- Name: paciente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paciente (
    id bigint NOT NULL,
    rut character varying(255) NOT NULL,
    nombre character varying(255) NOT NULL,
    apellidos character varying(255) NOT NULL,
    actividad_economica character varying(255),
    seguro integer,
    afp integer,
    ceco integer,
    area integer,
    cargo character varying(255),
    ciudad character varying(255),
    direccion character varying(255),
    donante boolean DEFAULT false,
    edad integer,
    email character varying(255),
    empresa integer,
    estado_civil integer,
    exposicion character varying(255),
    fecha_nacimiento date,
    grupo_sanguineo integer,
    instruccion integer,
    ley_social integer,
    ocupacion character varying(255),
    planta integer,
    prevision integer,
    profesion character varying(255),
    pueblo integer,
    religion integer,
    telefono1 character varying(255),
    telefono2 character varying(255),
    unidad integer,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now(),
    genero integer,
    modalidad character varying(255),
    areatxt character varying(255),
    activo boolean DEFAULT true,
    nacionalidad integer,
    email_verified_at character varying(255),
    remember_token character varying(255),
    password character varying(255),
    protocolo_minsal boolean DEFAULT false
);


ALTER TABLE public.paciente OWNER TO postgres;

--
-- Name: ListaCorreos; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."ListaCorreos" AS
 SELECT examen_epo.fecha_vencimiento,
    examen_epo.numero_solicitud,
    paciente.rut,
    paciente.nombre,
    paciente.apellidos,
    bateria.descripcion AS bateria,
    paciente.activo
   FROM ((public.paciente
     JOIN public.examen_epo ON ((paciente.id = examen_epo.paciente_id)))
     JOIN public.bateria ON ((examen_epo.bateria_id = bateria.id)))
  WHERE ((examen_epo.fecha_vencimiento >= '2024-12-15'::date) AND (examen_epo.fecha_vencimiento <= '2024-12-22'::date) AND (paciente.activo = true))
  ORDER BY examen_epo.fecha_vencimiento;


ALTER VIEW public."ListaCorreos" OWNER TO postgres;

--
-- Name: accidente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accidente (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.accidente OWNER TO postgres;

--
-- Name: accidente_condicion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accidente_condicion (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.accidente_condicion OWNER TO postgres;

--
-- Name: accidente_condicion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accidente_condicion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accidente_condicion_id_seq OWNER TO postgres;

--
-- Name: accidente_condicion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accidente_condicion_id_seq OWNED BY public.accidente_condicion.id;


--
-- Name: accidente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accidente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accidente_id_seq OWNER TO postgres;

--
-- Name: accidente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accidente_id_seq OWNED BY public.accidente.id;


--
-- Name: afp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.afp (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.afp OWNER TO postgres;

--
-- Name: afp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.afp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.afp_id_seq OWNER TO postgres;

--
-- Name: afp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.afp_id_seq OWNED BY public.afp.id;


--
-- Name: alergia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alergia (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    alergia character varying(255),
    comentario character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.alergia OWNER TO postgres;

--
-- Name: alergia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alergia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alergia_id_seq OWNER TO postgres;

--
-- Name: alergia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alergia_id_seq OWNED BY public.alergia.id;


--
-- Name: antecedente_familiar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.antecedente_familiar (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    patologia character varying(255),
    parentesco character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.antecedente_familiar OWNER TO postgres;

--
-- Name: antecedente_familiar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.antecedente_familiar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.antecedente_familiar_id_seq OWNER TO postgres;

--
-- Name: antecedente_familiar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.antecedente_familiar_id_seq OWNED BY public.antecedente_familiar.id;


--
-- Name: area; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.area (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.area OWNER TO postgres;

--
-- Name: area_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.area_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.area_id_seq OWNER TO postgres;

--
-- Name: area_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.area_id_seq OWNED BY public.area.id;


--
-- Name: atencion_diaria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.atencion_diaria (
    id bigint NOT NULL,
    paciente_id integer DEFAULT 0 NOT NULL,
    accidente integer DEFAULT 0,
    accidente_condicion integer DEFAULT 0,
    alerta_she boolean DEFAULT false,
    at_realizada_por character varying(255),
    calificacion integer DEFAULT 0,
    cuenta_acr boolean DEFAULT false,
    declaracion_completa boolean DEFAULT false,
    derivacion integer DEFAULT 0,
    derivacion_inmediata boolean DEFAULT false,
    descripcion_breve character varying(255),
    dias_descanso integer DEFAULT 0,
    error_critico integer DEFAULT 0,
    estado_mental integer DEFAULT 0,
    fecha_atencion date,
    fuente_incidente integer DEFAULT 0,
    hora_inicio time(0) without time zone,
    hora_termino time(0) without time zone,
    lugar_atencion integer DEFAULT 0,
    medicamentos character varying(255),
    medio_derivacion integer DEFAULT 0,
    motivo_consulta character varying(255),
    nombre_supervisor character varying(255),
    puede_reintegrarse boolean,
    "RECA" character varying(255),
    responsable integer DEFAULT 0,
    sistema_afectado integer DEFAULT 0,
    tipo_atencion integer DEFAULT 0,
    tipo_licencia integer DEFAULT 0,
    turno integer DEFAULT 0,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    acompanado boolean DEFAULT false,
    comentario text
);


ALTER TABLE public.atencion_diaria OWNER TO postgres;

--
-- Name: atencion_diaria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.atencion_diaria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.atencion_diaria_id_seq OWNER TO postgres;

--
-- Name: atencion_diaria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.atencion_diaria_id_seq OWNED BY public.atencion_diaria.id;


--
-- Name: bateria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bateria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bateria_id_seq OWNER TO postgres;

--
-- Name: bateria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bateria_id_seq OWNED BY public.bateria.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO postgres;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO postgres;

--
-- Name: calificacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calificacion (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.calificacion OWNER TO postgres;

--
-- Name: calificacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calificacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.calificacion_id_seq OWNER TO postgres;

--
-- Name: calificacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calificacion_id_seq OWNED BY public.calificacion.id;


--
-- Name: ceco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ceco (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.ceco OWNER TO postgres;

--
-- Name: ceco_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ceco_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ceco_id_seq OWNER TO postgres;

--
-- Name: ceco_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ceco_id_seq OWNED BY public.ceco.id;


--
-- Name: certificacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certificacion (
    id bigint NOT NULL,
    paciente_id bigint,
    certificacion character varying(255),
    fecha_certificacion date,
    fecha_caducidad date,
    estado_certificacion integer,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.certificacion OWNER TO postgres;

--
-- Name: certificacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.certificacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.certificacion_id_seq OWNER TO postgres;

--
-- Name: certificacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.certificacion_id_seq OWNED BY public.certificacion.id;


--
-- Name: cie10; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cie10 (
    id bigint NOT NULL,
    descripcion character varying(255),
    codigo character varying(20),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at time(0) with time zone DEFAULT now()
);


ALTER TABLE public.cie10 OWNER TO postgres;

--
-- Name: cie10_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cie10_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cie10_id_seq OWNER TO postgres;

--
-- Name: cie10_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cie10_id_seq OWNED BY public.cie10.id;


--
-- Name: cirugia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cirugia (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    cirugia character varying(255),
    comentario character varying(255),
    created_at timestamp(0) with time zone,
    updated_at timestamp(0) with time zone,
    fecha_cirugia character varying(255)
);


ALTER TABLE public.cirugia OWNER TO postgres;

--
-- Name: cirugia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cirugia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cirugia_id_seq OWNER TO postgres;

--
-- Name: cirugia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cirugia_id_seq OWNED BY public.cirugia.id;


--
-- Name: derivacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.derivacion (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.derivacion OWNER TO postgres;

--
-- Name: derivacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.derivacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.derivacion_id_seq OWNER TO postgres;

--
-- Name: derivacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.derivacion_id_seq OWNED BY public.derivacion.id;


--
-- Name: diat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.diat (
    paciente_id integer NOT NULL,
    accidente integer,
    seguro integer,
    comentario character varying(255),
    fecha_admision date,
    folio integer,
    numero_resolucion integer,
    origen_denuncia character varying(255),
    sucursal character varying(255),
    tipo_accidente integer,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    idpgp integer,
    validado_por character varying(255),
    estado_diat integer,
    id integer NOT NULL,
    aprobado boolean
);


ALTER TABLE public.diat OWNER TO postgres;

--
-- Name: diat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.diat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.diat_id_seq OWNER TO postgres;

--
-- Name: diat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.diat_id_seq OWNED BY public.diat.id;


--
-- Name: diep; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.diep (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    seguro integer,
    comentario character varying(255),
    fecha_admision date,
    folio integer,
    numero_resolucion integer,
    origen_denuncia character varying(255),
    tipo_enfermedad integer,
    validado_por character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    idpgp integer,
    enfermedad character varying(255),
    estado_diep character varying(255)
);


ALTER TABLE public.diep OWNER TO postgres;

--
-- Name: diep_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.diep_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.diep_id_seq OWNER TO postgres;

--
-- Name: diep_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.diep_id_seq OWNED BY public.diep.id;


--
-- Name: documentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documentos (
    id bigint NOT NULL,
    idatencion integer NOT NULL,
    size integer NOT NULL,
    name integer NOT NULL,
    archivo integer NOT NULL,
    "refID" integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.documentos OWNER TO postgres;

--
-- Name: documentos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.documentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documentos_id_seq OWNER TO postgres;

--
-- Name: documentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.documentos_id_seq OWNED BY public.documentos.id;


--
-- Name: empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empresa (
    id bigint NOT NULL,
    direccion character varying(255),
    email character varying(255),
    descripcion character varying(255) NOT NULL,
    razon_social character varying(255),
    representante character varying(255),
    responsable character varying(255),
    telefono character varying(255),
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now(),
    rut character varying(20)
);


ALTER TABLE public.empresa OWNER TO postgres;

--
-- Name: empresa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.empresa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.empresa_id_seq OWNER TO postgres;

--
-- Name: empresa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.empresa_id_seq OWNED BY public.empresa.id;


--
-- Name: enfermedad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.enfermedad (
    paciente_id integer NOT NULL,
    comentario character varying(255),
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now(),
    id integer NOT NULL,
    trastorno_cronico integer
);


ALTER TABLE public.enfermedad OWNER TO postgres;

--
-- Name: enfermedad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.enfermedad_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.enfermedad_id_seq OWNER TO postgres;

--
-- Name: enfermedad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.enfermedad_id_seq OWNED BY public.enfermedad.id;


--
-- Name: error_critico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.error_critico (
    id bigint NOT NULL,
    descripcion character varying(255),
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.error_critico OWNER TO postgres;

--
-- Name: error_critico_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.error_critico_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.error_critico_id_seq OWNER TO postgres;

--
-- Name: error_critico_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.error_critico_id_seq OWNED BY public.error_critico.id;


--
-- Name: estado_certificacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado_certificacion (
    id bigint NOT NULL,
    descripcion character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updatedd_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.estado_certificacion OWNER TO postgres;

--
-- Name: estado_certificacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_certificacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estado_certificacion_id_seq OWNER TO postgres;

--
-- Name: estado_certificacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_certificacion_id_seq OWNED BY public.estado_certificacion.id;


--
-- Name: estado_civil; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado_civil (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.estado_civil OWNER TO postgres;

--
-- Name: estado_civil_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_civil_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estado_civil_id_seq OWNER TO postgres;

--
-- Name: estado_civil_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_civil_id_seq OWNED BY public.estado_civil.id;


--
-- Name: estado_epo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado_epo (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.estado_epo OWNER TO postgres;

--
-- Name: estado_epo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_epo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estado_epo_id_seq OWNER TO postgres;

--
-- Name: estado_epo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_epo_id_seq OWNED BY public.estado_epo.id;


--
-- Name: estado_examen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado_examen (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.estado_examen OWNER TO postgres;

--
-- Name: estado_examen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_examen_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estado_examen_id_seq OWNER TO postgres;

--
-- Name: estado_examen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_examen_id_seq OWNED BY public.estado_examen.id;


--
-- Name: estado_mental; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado_mental (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.estado_mental OWNER TO postgres;

--
-- Name: estado_mental_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_mental_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estado_mental_id_seq OWNER TO postgres;

--
-- Name: estado_mental_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_mental_id_seq OWNED BY public.estado_mental.id;


--
-- Name: examen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.examen OWNER TO postgres;

--
-- Name: examen_asma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_asma (
    id bigint NOT NULL,
    estado_examen integer,
    paciente_id integer NOT NULL,
    idpgp integer,
    comentario character varying(255),
    fecha_control date,
    fecha_ingreso date,
    fecha_prox_control date,
    fecha_ult_control date,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.examen_asma OWNER TO postgres;

--
-- Name: examen_asma_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_asma_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_asma_id_seq OWNER TO postgres;

--
-- Name: examen_asma_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_asma_id_seq OWNED BY public.examen_asma.id;


--
-- Name: examen_ayd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_ayd (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    idpgp integer,
    fecha_control date,
    comentario character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    test_drogas integer
);


ALTER TABLE public.examen_ayd OWNER TO postgres;

--
-- Name: examen_ayd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_ayd_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_ayd_id_seq OWNER TO postgres;

--
-- Name: examen_ayd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_ayd_id_seq OWNED BY public.examen_ayd.id;


--
-- Name: examen_equilibrio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_equilibrio (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    fecha_examen date,
    comentario character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    resultado character varying(10) DEFAULT '"No Apto"'::character varying
);


ALTER TABLE public.examen_equilibrio OWNER TO postgres;

--
-- Name: examen_equilibrio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_equilibrio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_equilibrio_id_seq OWNER TO postgres;

--
-- Name: examen_equilibrio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_equilibrio_id_seq OWNED BY public.examen_equilibrio.id;


--
-- Name: examen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_id_seq OWNER TO postgres;

--
-- Name: examen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_id_seq OWNED BY public.examen.id;


--
-- Name: examen_psm; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_psm (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    contraindicacion character varying(255),
    fecha_solicitud date,
    fecha_realizacion date,
    fecha_recepcion date,
    fecha_vencimiento date,
    dias_restantes integer,
    comentario character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    tipo_vehiculo character varying(255),
    estado_examen integer
);


ALTER TABLE public.examen_psm OWNER TO postgres;

--
-- Name: examen_psm_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_psm_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_psm_id_seq OWNER TO postgres;

--
-- Name: examen_psm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_psm_id_seq OWNED BY public.examen_psm.id;


--
-- Name: examen_pvmoal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_pvmoal (
    paciente_id integer NOT NULL,
    idpgp integer NOT NULL,
    comentario character varying(255),
    fecha_control date,
    fecha_ingreso date,
    fecha_prox_control date,
    fecha_ult_control date,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    estado_examen integer,
    id integer NOT NULL
);


ALTER TABLE public.examen_pvmoal OWNER TO postgres;

--
-- Name: examen_pvmoal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_pvmoal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_pvmoal_id_seq OWNER TO postgres;

--
-- Name: examen_pvmoal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_pvmoal_id_seq OWNED BY public.examen_pvmoal.id;


--
-- Name: examen_pvmohn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_pvmohn (
    paciente_id integer NOT NULL,
    idpgp integer,
    comentario character varying(255),
    fecha_ingreso date,
    fecha_prox_control date,
    fecha_ult_control date,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    id integer NOT NULL,
    estado_examen integer,
    fecha_control date
);


ALTER TABLE public.examen_pvmohn OWNER TO postgres;

--
-- Name: examen_pvmohn_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_pvmohn_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_pvmohn_id_seq OWNER TO postgres;

--
-- Name: examen_pvmohn_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_pvmohn_id_seq OWNED BY public.examen_pvmohn.id;


--
-- Name: examen_pvmom; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_pvmom (
    paciente_id integer NOT NULL,
    idpgp integer,
    comentario character varying(255),
    fecha_ingreso date,
    fecha_prox_control date,
    fecha_ult_control date,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    estado_examen integer,
    id integer NOT NULL,
    fecha_control date
);


ALTER TABLE public.examen_pvmom OWNER TO postgres;

--
-- Name: examen_pvmom_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_pvmom_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_pvmom_id_seq OWNER TO postgres;

--
-- Name: examen_pvmom_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_pvmom_id_seq OWNED BY public.examen_pvmom.id;


--
-- Name: examen_pvmor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_pvmor (
    paciente_id integer NOT NULL,
    idpgp integer,
    comentario character varying(255),
    fecha_control date,
    fecha_ingreso date,
    fecha_prox_control date,
    fecha_ult_control date,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now(),
    estatus character varying(255),
    id integer NOT NULL,
    estado_examen integer
);


ALTER TABLE public.examen_pvmor OWNER TO postgres;

--
-- Name: examen_pvmor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_pvmor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_pvmor_id_seq OWNER TO postgres;

--
-- Name: examen_pvmor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_pvmor_id_seq OWNED BY public.examen_pvmor.id;


--
-- Name: examen_pvmos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_pvmos (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    idpgp integer,
    comentario character varying(255),
    fecha_control date,
    fecha_ingreso date,
    fecha_prox_control date,
    fecha_ult_control date,
    created_at time(0) without time zone DEFAULT now(),
    updated_at time(0) without time zone DEFAULT now(),
    estado_examen integer
);


ALTER TABLE public.examen_pvmos OWNER TO postgres;

--
-- Name: examen_pvmos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_pvmos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_pvmos_id_seq OWNER TO postgres;

--
-- Name: examen_pvmos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_pvmos_id_seq OWNED BY public.examen_pvmos.id;


--
-- Name: examen_pvmosol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_pvmosol (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    idpgp integer,
    comentario character varying(255),
    fecha_control date,
    fecha_ingreso date,
    fecha_prox_control date,
    fecha_ult_control date,
    created_at time(0) without time zone DEFAULT now(),
    updated_at time(0) without time zone DEFAULT now(),
    estado_examen integer
);


ALTER TABLE public.examen_pvmosol OWNER TO postgres;

--
-- Name: examen_pvmosol_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_pvmosol_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_pvmosol_id_seq OWNER TO postgres;

--
-- Name: examen_pvmosol_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_pvmosol_id_seq OWNED BY public.examen_pvmosol.id;


--
-- Name: examen_pvt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_pvt (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    fecha_examen date,
    fecha_control date,
    nordico character varying(255),
    quickdash character varying(255),
    derivacion character varying(255),
    comentario character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    estado_examen integer
);


ALTER TABLE public.examen_pvt OWNER TO postgres;

--
-- Name: examen_pvt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_pvt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_pvt_id_seq OWNER TO postgres;

--
-- Name: examen_pvt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_pvt_id_seq OWNED BY public.examen_pvt.id;


--
-- Name: examen_respirador; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_respirador (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    fecha_examen date,
    prueba_ajuste character varying(255),
    talla_respirador character varying(255),
    modelo_marca character varying(255),
    comentario character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.examen_respirador OWNER TO postgres;

--
-- Name: examen_respirador_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_respirador_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_respirador_id_seq OWNER TO postgres;

--
-- Name: examen_respirador_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_respirador_id_seq OWNED BY public.examen_respirador.id;


--
-- Name: examen_salud; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_salud (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    colesterol_hdl character varying(255),
    colesterol_ldl character varying(255),
    colesterol_total character varying(255),
    comentario character varying(255),
    creatinemia character varying(255),
    ecg character varying(255),
    espirometria character varying(255),
    estatus character varying(255),
    fecha_recepcion date,
    framingham character varying(255),
    glicemia character varying(255),
    hba1c character varying(255),
    hemoglobina character varying(255),
    hemograma character varying(255),
    optometria character varying(255),
    trigliceridos character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.examen_salud OWNER TO postgres;

--
-- Name: examen_salud_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_salud_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_salud_id_seq OWNER TO postgres;

--
-- Name: examen_salud_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_salud_id_seq OWNED BY public.examen_salud.id;


--
-- Name: examen_somnolencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.examen_somnolencia (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    comentario character varying(255),
    fecha_examen date,
    fecha_primer date,
    fecha_segundo date,
    resultado character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    nivel_riesgo integer
);


ALTER TABLE public.examen_somnolencia OWNER TO postgres;

--
-- Name: examen_somnolencia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.examen_somnolencia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examen_somnolencia_id_seq OWNER TO postgres;

--
-- Name: examen_somnolencia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.examen_somnolencia_id_seq OWNED BY public.examen_somnolencia.id;


--
-- Name: exposicion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exposicion (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.exposicion OWNER TO postgres;

--
-- Name: exposicion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exposicion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exposicion_id_seq OWNER TO postgres;

--
-- Name: exposicion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exposicion_id_seq OWNED BY public.exposicion.id;


--
-- Name: factor_riesgo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.factor_riesgo (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    factor_riesgo character varying(255),
    comentario character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.factor_riesgo OWNER TO postgres;

--
-- Name: factor_riesgo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.factor_riesgo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.factor_riesgo_id_seq OWNER TO postgres;

--
-- Name: factor_riesgo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.factor_riesgo_id_seq OWNED BY public.factor_riesgo.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: fuente_incidente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fuente_incidente (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.fuente_incidente OWNER TO postgres;

--
-- Name: fuente_incidente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fuente_incidente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fuente_incidente_id_seq OWNER TO postgres;

--
-- Name: fuente_incidente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fuente_incidente_id_seq OWNED BY public.fuente_incidente.id;


--
-- Name: genero; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genero (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.genero OWNER TO postgres;

--
-- Name: genero_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.genero_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.genero_id_seq OWNER TO postgres;

--
-- Name: genero_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.genero_id_seq OWNED BY public.genero.id;


--
-- Name: grupo_sanguineo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grupo_sanguineo (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.grupo_sanguineo OWNER TO postgres;

--
-- Name: grupo_sanguineo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grupo_sanguineo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.grupo_sanguineo_id_seq OWNER TO postgres;

--
-- Name: grupo_sanguineo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grupo_sanguineo_id_seq OWNED BY public.grupo_sanguineo.id;


--
-- Name: headers_tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.headers_tables (
    id bigint NOT NULL,
    tabla character varying(255) NOT NULL,
    idtabla integer NOT NULL,
    json character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.headers_tables OWNER TO postgres;

--
-- Name: headers_tables_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.headers_tables_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.headers_tables_id_seq OWNER TO postgres;

--
-- Name: headers_tables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.headers_tables_id_seq OWNED BY public.headers_tables.id;


--
-- Name: instruccion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instruccion (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.instruccion OWNER TO postgres;

--
-- Name: instruccion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.instruccion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.instruccion_id_seq OWNER TO postgres;

--
-- Name: instruccion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.instruccion_id_seq OWNED BY public.instruccion.id;


--
-- Name: ley_social; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ley_social (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.ley_social OWNER TO postgres;

--
-- Name: ley_social_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ley_social_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ley_social_id_seq OWNER TO postgres;

--
-- Name: ley_social_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ley_social_id_seq OWNED BY public.ley_social.id;


--
-- Name: licencia_medica; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.licencia_medica (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    comentario character varying(255),
    fecha_emision date,
    fecha_inicio date,
    fecha_recepcion date,
    fecha_termino date,
    folio integer,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now(),
    caract_reposo character varying(255),
    lugar_reposo character varying(255),
    tipo_licencia character varying(255),
    titulo_profesional character varying(255),
    nombre_profesional character varying(255),
    recuperabilidad_laboral boolean DEFAULT false,
    inicio_invalidez boolean DEFAULT false
);


ALTER TABLE public.licencia_medica OWNER TO postgres;

--
-- Name: licencia_medica_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.licencia_medica_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.licencia_medica_id_seq OWNER TO postgres;

--
-- Name: licencia_medica_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.licencia_medica_id_seq OWNED BY public.licencia_medica.id;


--
-- Name: lugar_atencion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lugar_atencion (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.lugar_atencion OWNER TO postgres;

--
-- Name: lugar_atencion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lugar_atencion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lugar_atencion_id_seq OWNER TO postgres;

--
-- Name: lugar_atencion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lugar_atencion_id_seq OWNED BY public.lugar_atencion.id;


--
-- Name: medicamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medicamento (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    medicamento character varying(255),
    comentario character varying(255),
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.medicamento OWNER TO postgres;

--
-- Name: medicamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.medicamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medicamento_id_seq OWNER TO postgres;

--
-- Name: medicamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.medicamento_id_seq OWNED BY public.medicamento.id;


--
-- Name: medio_derivacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medio_derivacion (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.medio_derivacion OWNER TO postgres;

--
-- Name: medio_derivacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.medio_derivacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medio_derivacion_id_seq OWNER TO postgres;

--
-- Name: medio_derivacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.medio_derivacion_id_seq OWNED BY public.medio_derivacion.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: modalidad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modalidad (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.modalidad OWNER TO postgres;

--
-- Name: modalidad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.modalidad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.modalidad_id_seq OWNER TO postgres;

--
-- Name: modalidad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.modalidad_id_seq OWNED BY public.modalidad.id;


--
-- Name: nacionalidad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nacionalidad (
    id integer NOT NULL,
    descripcion character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.nacionalidad OWNER TO postgres;

--
-- Name: nacionalidad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nacionalidad_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nacionalidad_id_seq OWNER TO postgres;

--
-- Name: nacionalidad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nacionalidad_id_seq OWNED BY public.nacionalidad.id;


--
-- Name: newpacientes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newpacientes (
    rut character varying(255)
);


ALTER TABLE public.newpacientes OWNER TO postgres;

--
-- Name: nivel_riesgo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nivel_riesgo (
    id bigint NOT NULL,
    descripcion character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.nivel_riesgo OWNER TO postgres;

--
-- Name: nivel_riesgo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nivel_riesgo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nivel_riesgo_id_seq OWNER TO postgres;

--
-- Name: nivel_riesgo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nivel_riesgo_id_seq OWNED BY public.nivel_riesgo.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    type character varying(255) NOT NULL,
    notifiable_type character varying(255) NOT NULL,
    notifiable_id bigint NOT NULL,
    data text NOT NULL,
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: paciente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paciente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.paciente_id_seq OWNER TO postgres;

--
-- Name: paciente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.paciente_id_seq OWNED BY public.paciente.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: planta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.planta (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.planta OWNER TO postgres;

--
-- Name: planta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.planta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.planta_id_seq OWNER TO postgres;

--
-- Name: planta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.planta_id_seq OWNED BY public.planta.id;


--
-- Name: prevision; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prevision (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.prevision OWNER TO postgres;

--
-- Name: prevision_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.prevision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prevision_id_seq OWNER TO postgres;

--
-- Name: prevision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.prevision_id_seq OWNED BY public.prevision.id;


--
-- Name: pueblo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pueblo (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.pueblo OWNER TO postgres;

--
-- Name: pueblo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pueblo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pueblo_id_seq OWNER TO postgres;

--
-- Name: pueblo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pueblo_id_seq OWNED BY public.pueblo.id;


--
-- Name: religion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.religion (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.religion OWNER TO postgres;

--
-- Name: religion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.religion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.religion_id_seq OWNER TO postgres;

--
-- Name: religion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.religion_id_seq OWNED BY public.religion.id;


--
-- Name: responsable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.responsable (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.responsable OWNER TO postgres;

--
-- Name: responsable_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.responsable_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.responsable_id_seq OWNER TO postgres;

--
-- Name: responsable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.responsable_id_seq OWNED BY public.responsable.id;


--
-- Name: ruts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ruts (
    rut character varying(255),
    password character varying(255)
);


ALTER TABLE public.ruts OWNER TO postgres;

--
-- Name: seguro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seguro (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.seguro OWNER TO postgres;

--
-- Name: seguro_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.seguro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seguro_id_seq OWNER TO postgres;

--
-- Name: seguro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.seguro_id_seq OWNED BY public.seguro.id;


--
-- Name: semaforo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.semaforo (
    id bigint NOT NULL,
    descripcion character varying(255),
    created_at character varying(255),
    updated_at timestamp(0) with time zone
);


ALTER TABLE public.semaforo OWNER TO postgres;

--
-- Name: semaforo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.semaforo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.semaforo_id_seq OWNER TO postgres;

--
-- Name: semaforo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.semaforo_id_seq OWNED BY public.semaforo.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: sistema_afectado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sistema_afectado (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.sistema_afectado OWNER TO postgres;

--
-- Name: sistema_afectado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sistema_afectado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sistema_afectado_id_seq OWNER TO postgres;

--
-- Name: sistema_afectado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sistema_afectado_id_seq OWNED BY public.sistema_afectado.id;


--
-- Name: team_invitations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_invitations (
    id bigint NOT NULL,
    team_id bigint NOT NULL,
    email character varying(255) NOT NULL,
    role character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.team_invitations OWNER TO postgres;

--
-- Name: team_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_invitations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_invitations_id_seq OWNER TO postgres;

--
-- Name: team_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_invitations_id_seq OWNED BY public.team_invitations.id;


--
-- Name: team_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_user (
    id bigint NOT NULL,
    team_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.team_user OWNER TO postgres;

--
-- Name: team_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_user_id_seq OWNER TO postgres;

--
-- Name: team_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_user_id_seq OWNED BY public.team_user.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teams (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    personal_team boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.teams OWNER TO postgres;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teams_id_seq OWNER TO postgres;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: test_drogas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_drogas (
    id bigint NOT NULL,
    descripcion character varying(255),
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.test_drogas OWNER TO postgres;

--
-- Name: test_drogas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_drogas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.test_drogas_id_seq OWNER TO postgres;

--
-- Name: test_drogas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_drogas_id_seq OWNED BY public.test_drogas.id;


--
-- Name: tipo_accidente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_accidente (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tipo_accidente OWNER TO postgres;

--
-- Name: tipo_accidente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_accidente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tipo_accidente_id_seq OWNER TO postgres;

--
-- Name: tipo_accidente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_accidente_id_seq OWNED BY public.tipo_accidente.id;


--
-- Name: tipo_atencion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_atencion (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tipo_atencion OWNER TO postgres;

--
-- Name: tipo_atencion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_atencion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tipo_atencion_id_seq OWNER TO postgres;

--
-- Name: tipo_atencion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_atencion_id_seq OWNED BY public.tipo_atencion.id;


--
-- Name: tipo_enfermedad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_enfermedad (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tipo_enfermedad OWNER TO postgres;

--
-- Name: tipo_enfermedad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_enfermedad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tipo_enfermedad_id_seq OWNER TO postgres;

--
-- Name: tipo_enfermedad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_enfermedad_id_seq OWNED BY public.tipo_enfermedad.id;


--
-- Name: tipo_examen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_examen (
    id bigint NOT NULL,
    descripcion character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.tipo_examen OWNER TO postgres;

--
-- Name: tipo_examen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_examen_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tipo_examen_id_seq OWNER TO postgres;

--
-- Name: tipo_examen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_examen_id_seq OWNED BY public.tipo_examen.id;


--
-- Name: tipo_licencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_licencia (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tipo_licencia OWNER TO postgres;

--
-- Name: tipo_licencia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_licencia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tipo_licencia_id_seq OWNER TO postgres;

--
-- Name: tipo_licencia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_licencia_id_seq OWNED BY public.tipo_licencia.id;


--
-- Name: trastorno_cronico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trastorno_cronico (
    id integer NOT NULL,
    descripcion character varying(255),
    cie10 character varying(255),
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE public.trastorno_cronico OWNER TO postgres;

--
-- Name: trastorno_cronico_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trastorno_cronico_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trastorno_cronico_id_seq OWNER TO postgres;

--
-- Name: trastorno_cronico_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trastorno_cronico_id_seq OWNED BY public.trastorno_cronico.id;


--
-- Name: turno; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.turno (
    id bigint NOT NULL,
    descripcion character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.turno OWNER TO postgres;

--
-- Name: turno_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.turno_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.turno_id_seq OWNER TO postgres;

--
-- Name: turno_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.turno_id_seq OWNED BY public.turno.id;


--
-- Name: unidad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.unidad (
    id bigint NOT NULL,
    area integer,
    descripcion character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.unidad OWNER TO postgres;

--
-- Name: unidad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.unidad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.unidad_id_seq OWNER TO postgres;

--
-- Name: unidad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.unidad_id_seq OWNED BY public.unidad.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    lastname character varying(255) NOT NULL,
    rut character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    current_team_id bigint,
    profile_photo_path character varying(2048),
    created_at timestamp(0) without time zone DEFAULT now(),
    updated_at timestamp(0) without time zone DEFAULT now(),
    two_factor_secret text,
    two_factor_recovery_codes text,
    two_factor_confirmed_at timestamp(0) without time zone,
    "isAdmin" boolean DEFAULT false,
    notification_exepo boolean DEFAULT false
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vacuna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vacuna (
    id bigint NOT NULL,
    paciente_id integer NOT NULL,
    vacuna character varying(255),
    tipo_vacuna character varying(255),
    fecha_vacuna character varying(255),
    comentario character varying(255),
    created_at timestamp(0) with time zone DEFAULT now(),
    updated_at timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE public.vacuna OWNER TO postgres;

--
-- Name: vacuna_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vacuna_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vacuna_id_seq OWNER TO postgres;

--
-- Name: vacuna_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vacuna_id_seq OWNED BY public.vacuna.id;


--
-- Name: accidente id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accidente ALTER COLUMN id SET DEFAULT nextval('public.accidente_id_seq'::regclass);


--
-- Name: accidente_condicion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accidente_condicion ALTER COLUMN id SET DEFAULT nextval('public.accidente_condicion_id_seq'::regclass);


--
-- Name: afp id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.afp ALTER COLUMN id SET DEFAULT nextval('public.afp_id_seq'::regclass);


--
-- Name: alergia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alergia ALTER COLUMN id SET DEFAULT nextval('public.alergia_id_seq'::regclass);


--
-- Name: antecedente_familiar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.antecedente_familiar ALTER COLUMN id SET DEFAULT nextval('public.antecedente_familiar_id_seq'::regclass);


--
-- Name: area id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.area ALTER COLUMN id SET DEFAULT nextval('public.area_id_seq'::regclass);


--
-- Name: atencion_diaria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atencion_diaria ALTER COLUMN id SET DEFAULT nextval('public.atencion_diaria_id_seq'::regclass);


--
-- Name: bateria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bateria ALTER COLUMN id SET DEFAULT nextval('public.bateria_id_seq'::regclass);


--
-- Name: calificacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calificacion ALTER COLUMN id SET DEFAULT nextval('public.calificacion_id_seq'::regclass);


--
-- Name: ceco id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ceco ALTER COLUMN id SET DEFAULT nextval('public.ceco_id_seq'::regclass);


--
-- Name: certificacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificacion ALTER COLUMN id SET DEFAULT nextval('public.certificacion_id_seq'::regclass);


--
-- Name: cie10 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cie10 ALTER COLUMN id SET DEFAULT nextval('public.cie10_id_seq'::regclass);


--
-- Name: cirugia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cirugia ALTER COLUMN id SET DEFAULT nextval('public.cirugia_id_seq'::regclass);


--
-- Name: derivacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.derivacion ALTER COLUMN id SET DEFAULT nextval('public.derivacion_id_seq'::regclass);


--
-- Name: diat id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diat ALTER COLUMN id SET DEFAULT nextval('public.diat_id_seq'::regclass);


--
-- Name: diep id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diep ALTER COLUMN id SET DEFAULT nextval('public.diep_id_seq'::regclass);


--
-- Name: documentos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documentos ALTER COLUMN id SET DEFAULT nextval('public.documentos_id_seq'::regclass);


--
-- Name: empresa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa ALTER COLUMN id SET DEFAULT nextval('public.empresa_id_seq'::regclass);


--
-- Name: enfermedad id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enfermedad ALTER COLUMN id SET DEFAULT nextval('public.enfermedad_id_seq'::regclass);


--
-- Name: error_critico id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.error_critico ALTER COLUMN id SET DEFAULT nextval('public.error_critico_id_seq'::regclass);


--
-- Name: estado_certificacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_certificacion ALTER COLUMN id SET DEFAULT nextval('public.estado_certificacion_id_seq'::regclass);


--
-- Name: estado_civil id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_civil ALTER COLUMN id SET DEFAULT nextval('public.estado_civil_id_seq'::regclass);


--
-- Name: estado_epo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_epo ALTER COLUMN id SET DEFAULT nextval('public.estado_epo_id_seq'::regclass);


--
-- Name: estado_examen id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_examen ALTER COLUMN id SET DEFAULT nextval('public.estado_examen_id_seq'::regclass);


--
-- Name: estado_mental id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_mental ALTER COLUMN id SET DEFAULT nextval('public.estado_mental_id_seq'::regclass);


--
-- Name: examen id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen ALTER COLUMN id SET DEFAULT nextval('public.examen_id_seq'::regclass);


--
-- Name: examen_asma id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_asma ALTER COLUMN id SET DEFAULT nextval('public.examen_asma_id_seq'::regclass);


--
-- Name: examen_ayd id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_ayd ALTER COLUMN id SET DEFAULT nextval('public.examen_ayd_id_seq'::regclass);


--
-- Name: examen_equilibrio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_equilibrio ALTER COLUMN id SET DEFAULT nextval('public.examen_equilibrio_id_seq'::regclass);


--
-- Name: examen_psm id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_psm ALTER COLUMN id SET DEFAULT nextval('public.examen_psm_id_seq'::regclass);


--
-- Name: examen_pvmoal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmoal ALTER COLUMN id SET DEFAULT nextval('public.examen_pvmoal_id_seq'::regclass);


--
-- Name: examen_pvmohn id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmohn ALTER COLUMN id SET DEFAULT nextval('public.examen_pvmohn_id_seq'::regclass);


--
-- Name: examen_pvmom id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmom ALTER COLUMN id SET DEFAULT nextval('public.examen_pvmom_id_seq'::regclass);


--
-- Name: examen_pvmor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmor ALTER COLUMN id SET DEFAULT nextval('public.examen_pvmor_id_seq'::regclass);


--
-- Name: examen_pvmos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmos ALTER COLUMN id SET DEFAULT nextval('public.examen_pvmos_id_seq'::regclass);


--
-- Name: examen_pvmosol id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmosol ALTER COLUMN id SET DEFAULT nextval('public.examen_pvmosol_id_seq'::regclass);


--
-- Name: examen_pvt id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvt ALTER COLUMN id SET DEFAULT nextval('public.examen_pvt_id_seq'::regclass);


--
-- Name: examen_respirador id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_respirador ALTER COLUMN id SET DEFAULT nextval('public.examen_respirador_id_seq'::regclass);


--
-- Name: examen_salud id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_salud ALTER COLUMN id SET DEFAULT nextval('public.examen_salud_id_seq'::regclass);


--
-- Name: examen_somnolencia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_somnolencia ALTER COLUMN id SET DEFAULT nextval('public.examen_somnolencia_id_seq'::regclass);


--
-- Name: exposicion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exposicion ALTER COLUMN id SET DEFAULT nextval('public.exposicion_id_seq'::regclass);


--
-- Name: factor_riesgo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factor_riesgo ALTER COLUMN id SET DEFAULT nextval('public.factor_riesgo_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: fuente_incidente id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fuente_incidente ALTER COLUMN id SET DEFAULT nextval('public.fuente_incidente_id_seq'::regclass);


--
-- Name: genero id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genero ALTER COLUMN id SET DEFAULT nextval('public.genero_id_seq'::regclass);


--
-- Name: grupo_sanguineo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grupo_sanguineo ALTER COLUMN id SET DEFAULT nextval('public.grupo_sanguineo_id_seq'::regclass);


--
-- Name: headers_tables id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.headers_tables ALTER COLUMN id SET DEFAULT nextval('public.headers_tables_id_seq'::regclass);


--
-- Name: instruccion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instruccion ALTER COLUMN id SET DEFAULT nextval('public.instruccion_id_seq'::regclass);


--
-- Name: ley_social id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ley_social ALTER COLUMN id SET DEFAULT nextval('public.ley_social_id_seq'::regclass);


--
-- Name: licencia_medica id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.licencia_medica ALTER COLUMN id SET DEFAULT nextval('public.licencia_medica_id_seq'::regclass);


--
-- Name: lugar_atencion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lugar_atencion ALTER COLUMN id SET DEFAULT nextval('public.lugar_atencion_id_seq'::regclass);


--
-- Name: medicamento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicamento ALTER COLUMN id SET DEFAULT nextval('public.medicamento_id_seq'::regclass);


--
-- Name: medio_derivacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medio_derivacion ALTER COLUMN id SET DEFAULT nextval('public.medio_derivacion_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: modalidad id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modalidad ALTER COLUMN id SET DEFAULT nextval('public.modalidad_id_seq'::regclass);


--
-- Name: nacionalidad id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nacionalidad ALTER COLUMN id SET DEFAULT nextval('public.nacionalidad_id_seq'::regclass);


--
-- Name: nivel_riesgo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nivel_riesgo ALTER COLUMN id SET DEFAULT nextval('public.nivel_riesgo_id_seq'::regclass);


--
-- Name: paciente id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paciente ALTER COLUMN id SET DEFAULT nextval('public.paciente_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: planta id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.planta ALTER COLUMN id SET DEFAULT nextval('public.planta_id_seq'::regclass);


--
-- Name: prevision id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prevision ALTER COLUMN id SET DEFAULT nextval('public.prevision_id_seq'::regclass);


--
-- Name: pueblo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pueblo ALTER COLUMN id SET DEFAULT nextval('public.pueblo_id_seq'::regclass);


--
-- Name: religion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.religion ALTER COLUMN id SET DEFAULT nextval('public.religion_id_seq'::regclass);


--
-- Name: responsable id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.responsable ALTER COLUMN id SET DEFAULT nextval('public.responsable_id_seq'::regclass);


--
-- Name: seguro id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seguro ALTER COLUMN id SET DEFAULT nextval('public.seguro_id_seq'::regclass);


--
-- Name: semaforo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.semaforo ALTER COLUMN id SET DEFAULT nextval('public.semaforo_id_seq'::regclass);


--
-- Name: sistema_afectado id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sistema_afectado ALTER COLUMN id SET DEFAULT nextval('public.sistema_afectado_id_seq'::regclass);


--
-- Name: team_invitations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_invitations ALTER COLUMN id SET DEFAULT nextval('public.team_invitations_id_seq'::regclass);


--
-- Name: team_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_user ALTER COLUMN id SET DEFAULT nextval('public.team_user_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: test_drogas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_drogas ALTER COLUMN id SET DEFAULT nextval('public.test_drogas_id_seq'::regclass);


--
-- Name: tipo_accidente id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_accidente ALTER COLUMN id SET DEFAULT nextval('public.tipo_accidente_id_seq'::regclass);


--
-- Name: tipo_atencion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_atencion ALTER COLUMN id SET DEFAULT nextval('public.tipo_atencion_id_seq'::regclass);


--
-- Name: tipo_enfermedad id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_enfermedad ALTER COLUMN id SET DEFAULT nextval('public.tipo_enfermedad_id_seq'::regclass);


--
-- Name: tipo_examen id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_examen ALTER COLUMN id SET DEFAULT nextval('public.tipo_examen_id_seq'::regclass);


--
-- Name: tipo_licencia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_licencia ALTER COLUMN id SET DEFAULT nextval('public.tipo_licencia_id_seq'::regclass);


--
-- Name: trastorno_cronico id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trastorno_cronico ALTER COLUMN id SET DEFAULT nextval('public.trastorno_cronico_id_seq'::regclass);


--
-- Name: turno id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turno ALTER COLUMN id SET DEFAULT nextval('public.turno_id_seq'::regclass);


--
-- Name: unidad id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unidad ALTER COLUMN id SET DEFAULT nextval('public.unidad_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vacuna id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna ALTER COLUMN id SET DEFAULT nextval('public.vacuna_id_seq'::regclass);


--
-- Data for Name: accidente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accidente (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: accidente_condicion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accidente_condicion (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: afp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.afp (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alergia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alergia (id, paciente_id, alergia, comentario, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: antecedente_familiar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.antecedente_familiar (id, paciente_id, patologia, parentesco, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: area; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.area (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: atencion_diaria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.atencion_diaria (id, paciente_id, accidente, accidente_condicion, alerta_she, at_realizada_por, calificacion, cuenta_acr, declaracion_completa, derivacion, derivacion_inmediata, descripcion_breve, dias_descanso, error_critico, estado_mental, fecha_atencion, fuente_incidente, hora_inicio, hora_termino, lugar_atencion, medicamentos, medio_derivacion, motivo_consulta, nombre_supervisor, puede_reintegrarse, "RECA", responsable, sistema_afectado, tipo_atencion, tipo_licencia, turno, created_at, updated_at, acompanado, comentario) FROM stdin;
\.


--
-- Data for Name: bateria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bateria (descripcion, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: calificacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calificacion (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ceco; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ceco (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: certificacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certificacion (id, paciente_id, certificacion, fecha_certificacion, fecha_caducidad, estado_certificacion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cie10; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cie10 (id, descripcion, codigo, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cirugia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cirugia (id, paciente_id, cirugia, comentario, created_at, updated_at, fecha_cirugia) FROM stdin;
\.


--
-- Data for Name: derivacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.derivacion (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: diat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.diat (paciente_id, accidente, seguro, comentario, fecha_admision, folio, numero_resolucion, origen_denuncia, sucursal, tipo_accidente, created_at, updated_at, idpgp, validado_por, estado_diat, id, aprobado) FROM stdin;
\.


--
-- Data for Name: diep; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.diep (id, paciente_id, seguro, comentario, fecha_admision, folio, numero_resolucion, origen_denuncia, tipo_enfermedad, validado_por, created_at, updated_at, idpgp, enfermedad, estado_diep) FROM stdin;
\.


--
-- Data for Name: documentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documentos (id, idatencion, size, name, archivo, "refID", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.empresa (id, direccion, email, descripcion, razon_social, representante, responsable, telefono, created_at, updated_at, rut) FROM stdin;
\.


--
-- Data for Name: enfermedad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.enfermedad (paciente_id, comentario, created_at, updated_at, id, trastorno_cronico) FROM stdin;
\.


--
-- Data for Name: error_critico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.error_critico (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: estado_certificacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estado_certificacion (id, descripcion, created_at, updatedd_at) FROM stdin;
\.


--
-- Data for Name: estado_civil; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estado_civil (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: estado_epo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estado_epo (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: estado_examen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estado_examen (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: estado_mental; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estado_mental (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: examen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: examen_asma; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_asma (id, estado_examen, paciente_id, idpgp, comentario, fecha_control, fecha_ingreso, fecha_prox_control, fecha_ult_control, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: examen_ayd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_ayd (id, paciente_id, idpgp, fecha_control, comentario, created_at, updated_at, test_drogas) FROM stdin;
\.


--
-- Data for Name: examen_epo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_epo (paciente_id, comentario, fecha_realizacion, fecha_recepcion, fecha_solicitud, fecha_vencimiento, numero_solicitud, resultado, tipo_examen, created_at, updated_at, semaforo, estado_epo, id, bateria_id, codigo_verificacion) FROM stdin;
\.


--
-- Data for Name: examen_equilibrio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_equilibrio (id, paciente_id, fecha_examen, comentario, created_at, updated_at, resultado) FROM stdin;
\.


--
-- Data for Name: examen_psm; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_psm (id, paciente_id, contraindicacion, fecha_solicitud, fecha_realizacion, fecha_recepcion, fecha_vencimiento, dias_restantes, comentario, created_at, updated_at, tipo_vehiculo, estado_examen) FROM stdin;
\.


--
-- Data for Name: examen_pvmoal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_pvmoal (paciente_id, idpgp, comentario, fecha_control, fecha_ingreso, fecha_prox_control, fecha_ult_control, created_at, updated_at, estado_examen, id) FROM stdin;
\.


--
-- Data for Name: examen_pvmohn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_pvmohn (paciente_id, idpgp, comentario, fecha_ingreso, fecha_prox_control, fecha_ult_control, created_at, updated_at, id, estado_examen, fecha_control) FROM stdin;
\.


--
-- Data for Name: examen_pvmom; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_pvmom (paciente_id, idpgp, comentario, fecha_ingreso, fecha_prox_control, fecha_ult_control, created_at, updated_at, estado_examen, id, fecha_control) FROM stdin;
\.


--
-- Data for Name: examen_pvmor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_pvmor (paciente_id, idpgp, comentario, fecha_control, fecha_ingreso, fecha_prox_control, fecha_ult_control, created_at, updated_at, estatus, id, estado_examen) FROM stdin;
\.


--
-- Data for Name: examen_pvmos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_pvmos (id, paciente_id, idpgp, comentario, fecha_control, fecha_ingreso, fecha_prox_control, fecha_ult_control, created_at, updated_at, estado_examen) FROM stdin;
\.


--
-- Data for Name: examen_pvmosol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_pvmosol (id, paciente_id, idpgp, comentario, fecha_control, fecha_ingreso, fecha_prox_control, fecha_ult_control, created_at, updated_at, estado_examen) FROM stdin;
\.


--
-- Data for Name: examen_pvt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_pvt (id, paciente_id, fecha_examen, fecha_control, nordico, quickdash, derivacion, comentario, created_at, updated_at, estado_examen) FROM stdin;
\.


--
-- Data for Name: examen_respirador; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_respirador (id, paciente_id, fecha_examen, prueba_ajuste, talla_respirador, modelo_marca, comentario, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: examen_salud; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_salud (id, paciente_id, colesterol_hdl, colesterol_ldl, colesterol_total, comentario, creatinemia, ecg, espirometria, estatus, fecha_recepcion, framingham, glicemia, hba1c, hemoglobina, hemograma, optometria, trigliceridos, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: examen_somnolencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.examen_somnolencia (id, paciente_id, comentario, fecha_examen, fecha_primer, fecha_segundo, resultado, created_at, updated_at, nivel_riesgo) FROM stdin;
\.


--
-- Data for Name: exposicion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exposicion (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: factor_riesgo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.factor_riesgo (id, paciente_id, factor_riesgo, comentario, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: fuente_incidente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fuente_incidente (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: genero; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.genero (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grupo_sanguineo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grupo_sanguineo (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: headers_tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.headers_tables (id, tabla, idtabla, json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: instruccion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.instruccion (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ley_social; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ley_social (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: licencia_medica; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.licencia_medica (id, paciente_id, comentario, fecha_emision, fecha_inicio, fecha_recepcion, fecha_termino, folio, created_at, updated_at, caract_reposo, lugar_reposo, tipo_licencia, titulo_profesional, nombre_profesional, recuperabilidad_laboral, inicio_invalidez) FROM stdin;
\.


--
-- Data for Name: lugar_atencion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lugar_atencion (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: medicamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medicamento (id, paciente_id, medicamento, comentario, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: medio_derivacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medio_derivacion (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2025_01_21_124355_create_accidente_condicion_table	1
2	2025_01_21_124355_create_accidente_table	1
3	2025_01_21_124355_create_afp_table	1
4	2025_01_21_124355_create_alergia_table	1
5	2025_01_21_124355_create_antecedente_familiar_table	1
6	2025_01_21_124355_create_area_table	1
7	2025_01_21_124355_create_atencion_diaria_table	1
8	2025_01_21_124355_create_bateria_table	1
9	2025_01_21_124355_create_cache_locks_table	1
10	2025_01_21_124355_create_cache_table	1
11	2025_01_21_124355_create_calificacion_table	1
12	2025_01_21_124355_create_ceco_table	1
13	2025_01_21_124355_create_certificacion_table	1
14	2025_01_21_124355_create_cie10_table	1
15	2025_01_21_124355_create_cirugia_table	1
16	2025_01_21_124355_create_derivacion_table	1
17	2025_01_21_124355_create_diat_table	1
18	2025_01_21_124355_create_diep_table	1
19	2025_01_21_124355_create_documentos_table	1
20	2025_01_21_124355_create_empresa_table	1
21	2025_01_21_124355_create_enfermedad_table	1
22	2025_01_21_124355_create_error_critico_table	1
23	2025_01_21_124355_create_estado_certificacion_table	1
24	2025_01_21_124355_create_estado_civil_table	1
25	2025_01_21_124355_create_estado_epo_table	1
26	2025_01_21_124355_create_estado_examen_table	1
27	2025_01_21_124355_create_estado_mental_table	1
28	2025_01_21_124355_create_examen_asma_table	1
29	2025_01_21_124355_create_examen_ayd_table	1
30	2025_01_21_124355_create_examen_epo_table	1
31	2025_01_21_124355_create_examen_equilibrio_table	1
32	2025_01_21_124355_create_examen_psm_table	1
33	2025_01_21_124355_create_examen_pvmoal_table	1
34	2025_01_21_124355_create_examen_pvmohn_table	1
35	2025_01_21_124355_create_examen_pvmom_table	1
36	2025_01_21_124355_create_examen_pvmor_table	1
37	2025_01_21_124355_create_examen_pvmos_table	1
38	2025_01_21_124355_create_examen_pvmosol_table	1
39	2025_01_21_124355_create_examen_pvt_table	1
40	2025_01_21_124355_create_examen_respirador_table	1
41	2025_01_21_124355_create_examen_salud_table	1
42	2025_01_21_124355_create_examen_somnolencia_table	1
43	2025_01_21_124355_create_examen_table	1
44	2025_01_21_124355_create_exposicion_table	1
45	2025_01_21_124355_create_factor_riesgo_table	1
46	2025_01_21_124355_create_failed_jobs_table	1
47	2025_01_21_124355_create_fuente_incidente_table	1
48	2025_01_21_124355_create_genero_table	1
49	2025_01_21_124355_create_grupo_sanguineo_table	1
50	2025_01_21_124355_create_headers_tables_table	1
51	2025_01_21_124355_create_instruccion_table	1
52	2025_01_21_124355_create_ley_social_table	1
53	2025_01_21_124355_create_licencia_medica_table	1
54	2025_01_21_124355_create_lugar_atencion_table	1
55	2025_01_21_124355_create_medicamento_table	1
56	2025_01_21_124355_create_medio_derivacion_table	1
57	2025_01_21_124355_create_modalidad_table	1
58	2025_01_21_124355_create_nacionalidad_table	1
59	2025_01_21_124355_create_newpacientes_table	1
60	2025_01_21_124355_create_nivel_riesgo_table	1
61	2025_01_21_124355_create_notifications_table	1
62	2025_01_21_124355_create_paciente_table	1
63	2025_01_21_124355_create_password_reset_tokens_table	1
64	2025_01_21_124355_create_personal_access_tokens_table	1
65	2025_01_21_124355_create_planta_table	1
66	2025_01_21_124355_create_prevision_table	1
67	2025_01_21_124355_create_pueblo_table	1
68	2025_01_21_124355_create_religion_table	1
69	2025_01_21_124355_create_responsable_table	1
70	2025_01_21_124355_create_ruts_table	1
71	2025_01_21_124355_create_seguro_table	1
72	2025_01_21_124355_create_semaforo_table	1
73	2025_01_21_124355_create_sessions_table	1
74	2025_01_21_124355_create_sistema_afectado_table	1
75	2025_01_21_124355_create_team_invitations_table	1
76	2025_01_21_124355_create_team_user_table	1
77	2025_01_21_124355_create_teams_table	1
78	2025_01_21_124355_create_test_drogas_table	1
79	2025_01_21_124355_create_tipo_accidente_table	1
80	2025_01_21_124355_create_tipo_atencion_table	1
81	2025_01_21_124355_create_tipo_enfermedad_table	1
82	2025_01_21_124355_create_tipo_examen_table	1
83	2025_01_21_124355_create_tipo_licencia_table	1
84	2025_01_21_124355_create_trastorno_cronico_table	1
85	2025_01_21_124355_create_turno_table	1
86	2025_01_21_124355_create_unidad_table	1
87	2025_01_21_124355_create_users_table	1
88	2025_01_21_124355_create_vacuna_table	1
89	2025_01_21_124356_create_ListaCorreos_view	1
90	2025_01_21_124358_add_foreign_keys_to_examen_epo_table	1
91	2025_01_21_124358_add_foreign_keys_to_team_invitations_table	1
\.


--
-- Data for Name: modalidad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modalidad (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nacionalidad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nacionalidad (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: newpacientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.newpacientes (rut) FROM stdin;
\.


--
-- Data for Name: nivel_riesgo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nivel_riesgo (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, type, notifiable_type, notifiable_id, data, read_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: paciente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paciente (id, rut, nombre, apellidos, actividad_economica, seguro, afp, ceco, area, cargo, ciudad, direccion, donante, edad, email, empresa, estado_civil, exposicion, fecha_nacimiento, grupo_sanguineo, instruccion, ley_social, ocupacion, planta, prevision, profesion, pueblo, religion, telefono1, telefono2, unidad, created_at, updated_at, genero, modalidad, areatxt, activo, nacionalidad, email_verified_at, remember_token, password, protocolo_minsal) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: planta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.planta (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: prevision; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prevision (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pueblo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pueblo (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: religion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.religion (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: responsable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.responsable (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ruts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ruts (rut, password) FROM stdin;
\.


--
-- Data for Name: seguro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.seguro (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: semaforo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.semaforo (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
\.


--
-- Data for Name: sistema_afectado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sistema_afectado (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: team_invitations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_invitations (id, team_id, email, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: team_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_user (id, team_id, user_id, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teams (id, user_id, name, personal_team, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: test_drogas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_drogas (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tipo_accidente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_accidente (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tipo_atencion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_atencion (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tipo_enfermedad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_enfermedad (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tipo_examen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_examen (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tipo_licencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_licencia (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: trastorno_cronico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trastorno_cronico (id, descripcion, cie10, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: turno; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.turno (id, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: unidad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.unidad (id, area, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, lastname, rut, email, email_verified_at, password, remember_token, current_team_id, profile_photo_path, created_at, updated_at, two_factor_secret, two_factor_recovery_codes, two_factor_confirmed_at, "isAdmin", notification_exepo) FROM stdin;
\.


--
-- Data for Name: vacuna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vacuna (id, paciente_id, vacuna, tipo_vacuna, fecha_vacuna, comentario, created_at, updated_at) FROM stdin;
\.


--
-- Name: accidente_condicion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accidente_condicion_id_seq', 1, false);


--
-- Name: accidente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accidente_id_seq', 1, false);


--
-- Name: afp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.afp_id_seq', 1, false);


--
-- Name: alergia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alergia_id_seq', 1, false);


--
-- Name: antecedente_familiar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.antecedente_familiar_id_seq', 1, false);


--
-- Name: area_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.area_id_seq', 4, true);


--
-- Name: atencion_diaria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.atencion_diaria_id_seq', 1, false);


--
-- Name: bateria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bateria_id_seq', 1, false);


--
-- Name: calificacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calificacion_id_seq', 1, false);


--
-- Name: ceco_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ceco_id_seq', 1, false);


--
-- Name: certificacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.certificacion_id_seq', 1, false);


--
-- Name: cie10_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cie10_id_seq', 1, false);


--
-- Name: cirugia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cirugia_id_seq', 1, false);


--
-- Name: derivacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.derivacion_id_seq', 1, false);


--
-- Name: diat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.diat_id_seq', 1, false);


--
-- Name: diep_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.diep_id_seq', 1, false);


--
-- Name: documentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.documentos_id_seq', 1, false);


--
-- Name: empresa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.empresa_id_seq', 4, true);


--
-- Name: enfermedad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.enfermedad_id_seq', 1, false);


--
-- Name: error_critico_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.error_critico_id_seq', 1, false);


--
-- Name: estado_certificacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estado_certificacion_id_seq', 1, false);


--
-- Name: estado_civil_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estado_civil_id_seq', 1, false);


--
-- Name: estado_epo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estado_epo_id_seq', 1, false);


--
-- Name: estado_examen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estado_examen_id_seq', 1, false);


--
-- Name: estado_mental_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estado_mental_id_seq', 1, false);


--
-- Name: examen_asma_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_asma_id_seq', 1, false);


--
-- Name: examen_ayd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_ayd_id_seq', 1, false);


--
-- Name: examen_equilibrio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_equilibrio_id_seq', 1, false);


--
-- Name: examen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_id_seq', 1, false);


--
-- Name: examen_psm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_psm_id_seq', 1, false);


--
-- Name: examen_pvmoal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_pvmoal_id_seq', 1, false);


--
-- Name: examen_pvmohn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_pvmohn_id_seq', 1, false);


--
-- Name: examen_pvmom_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_pvmom_id_seq', 1, false);


--
-- Name: examen_pvmor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_pvmor_id_seq', 1, false);


--
-- Name: examen_pvmos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_pvmos_id_seq', 1, false);


--
-- Name: examen_pvmosol_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_pvmosol_id_seq', 1, false);


--
-- Name: examen_pvt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_pvt_id_seq', 1, false);


--
-- Name: examen_respirador_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_respirador_id_seq', 1, false);


--
-- Name: examen_salud_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_salud_id_seq', 1, false);


--
-- Name: examen_somnolencia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.examen_somnolencia_id_seq', 1, false);


--
-- Name: exposicion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exposicion_id_seq', 2, true);


--
-- Name: factor_riesgo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.factor_riesgo_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: fuente_incidente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fuente_incidente_id_seq', 1, false);


--
-- Name: genero_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.genero_id_seq', 1, false);


--
-- Name: grupo_sanguineo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grupo_sanguineo_id_seq', 1, false);


--
-- Name: headers_tables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.headers_tables_id_seq', 1, false);


--
-- Name: instruccion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.instruccion_id_seq', 1, false);


--
-- Name: ley_social_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ley_social_id_seq', 1, false);


--
-- Name: licencia_medica_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.licencia_medica_id_seq', 1, false);


--
-- Name: lugar_atencion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lugar_atencion_id_seq', 1, false);


--
-- Name: medicamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.medicamento_id_seq', 1, false);


--
-- Name: medio_derivacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.medio_derivacion_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 91, true);


--
-- Name: modalidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.modalidad_id_seq', 1, false);


--
-- Name: nacionalidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nacionalidad_id_seq', 1, false);


--
-- Name: nivel_riesgo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nivel_riesgo_id_seq', 1, false);


--
-- Name: paciente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paciente_id_seq', 1, false);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: planta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.planta_id_seq', 1, false);


--
-- Name: prevision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prevision_id_seq', 1, false);


--
-- Name: pueblo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pueblo_id_seq', 1, false);


--
-- Name: religion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.religion_id_seq', 1, false);


--
-- Name: responsable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.responsable_id_seq', 1, false);


--
-- Name: seguro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.seguro_id_seq', 1, false);


--
-- Name: semaforo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.semaforo_id_seq', 1, false);


--
-- Name: sistema_afectado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sistema_afectado_id_seq', 1, false);


--
-- Name: team_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_invitations_id_seq', 1, false);


--
-- Name: team_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_user_id_seq', 1, false);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teams_id_seq', 1, false);


--
-- Name: test_drogas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_drogas_id_seq', 1, false);


--
-- Name: tipo_accidente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_accidente_id_seq', 1, false);


--
-- Name: tipo_atencion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_atencion_id_seq', 1, false);


--
-- Name: tipo_enfermedad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_enfermedad_id_seq', 1, false);


--
-- Name: tipo_examen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_examen_id_seq', 1, false);


--
-- Name: tipo_licencia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_licencia_id_seq', 1, false);


--
-- Name: trastorno_cronico_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trastorno_cronico_id_seq', 1, false);


--
-- Name: turno_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.turno_id_seq', 1, false);


--
-- Name: unidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.unidad_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: vacuna_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vacuna_id_seq', 1, false);


--
-- Name: accidente_condicion accidente_condicion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accidente_condicion
    ADD CONSTRAINT accidente_condicion_pkey PRIMARY KEY (id);


--
-- Name: accidente accidente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accidente
    ADD CONSTRAINT accidente_pkey PRIMARY KEY (id);


--
-- Name: afp afp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.afp
    ADD CONSTRAINT afp_pkey PRIMARY KEY (id);


--
-- Name: alergia alergia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alergia
    ADD CONSTRAINT alergia_pkey PRIMARY KEY (id);


--
-- Name: antecedente_familiar antecedente_familiar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.antecedente_familiar
    ADD CONSTRAINT antecedente_familiar_pkey PRIMARY KEY (id);


--
-- Name: area area_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.area
    ADD CONSTRAINT area_pkey PRIMARY KEY (id);


--
-- Name: atencion_diaria atencion_diaria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atencion_diaria
    ADD CONSTRAINT atencion_diaria_pkey PRIMARY KEY (id);


--
-- Name: bateria bateria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bateria
    ADD CONSTRAINT bateria_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: calificacion calificacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calificacion
    ADD CONSTRAINT calificacion_pkey PRIMARY KEY (id);


--
-- Name: ceco ceco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ceco
    ADD CONSTRAINT ceco_pkey PRIMARY KEY (id);


--
-- Name: certificacion certificacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificacion
    ADD CONSTRAINT certificacion_pkey PRIMARY KEY (id);


--
-- Name: cie10 cie10_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cie10
    ADD CONSTRAINT cie10_pkey PRIMARY KEY (id);


--
-- Name: cirugia cirugia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cirugia
    ADD CONSTRAINT cirugia_pkey PRIMARY KEY (id);


--
-- Name: derivacion derivacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.derivacion
    ADD CONSTRAINT derivacion_pkey PRIMARY KEY (id);


--
-- Name: diat diat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diat
    ADD CONSTRAINT diat_pkey PRIMARY KEY (id);


--
-- Name: diep diep_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diep
    ADD CONSTRAINT diep_pkey PRIMARY KEY (id);


--
-- Name: documentos documentos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documentos
    ADD CONSTRAINT documentos_pkey PRIMARY KEY (id);


--
-- Name: empresa empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa
    ADD CONSTRAINT empresa_pkey PRIMARY KEY (id);


--
-- Name: enfermedad enfermedad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enfermedad
    ADD CONSTRAINT enfermedad_pkey PRIMARY KEY (id);


--
-- Name: error_critico error_critico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.error_critico
    ADD CONSTRAINT error_critico_pkey PRIMARY KEY (id);


--
-- Name: estado_certificacion estado_certificacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_certificacion
    ADD CONSTRAINT estado_certificacion_pkey PRIMARY KEY (id);


--
-- Name: estado_civil estado_civil_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_civil
    ADD CONSTRAINT estado_civil_pkey PRIMARY KEY (id);


--
-- Name: estado_epo estado_epo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_epo
    ADD CONSTRAINT estado_epo_pkey PRIMARY KEY (id);


--
-- Name: estado_examen estado_examen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_examen
    ADD CONSTRAINT estado_examen_pkey PRIMARY KEY (id);


--
-- Name: estado_mental estado_mental_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_mental
    ADD CONSTRAINT estado_mental_pkey PRIMARY KEY (id);


--
-- Name: examen_asma examen_asma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_asma
    ADD CONSTRAINT examen_asma_pkey PRIMARY KEY (id);


--
-- Name: examen_ayd examen_ayd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_ayd
    ADD CONSTRAINT examen_ayd_pkey PRIMARY KEY (id);


--
-- Name: examen_epo examen_epo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_epo
    ADD CONSTRAINT examen_epo_pkey PRIMARY KEY (id);


--
-- Name: examen_equilibrio examen_equilibrio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_equilibrio
    ADD CONSTRAINT examen_equilibrio_pkey PRIMARY KEY (id);


--
-- Name: examen examen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen
    ADD CONSTRAINT examen_pkey PRIMARY KEY (id);


--
-- Name: examen_psm examen_psm_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_psm
    ADD CONSTRAINT examen_psm_pkey PRIMARY KEY (id);


--
-- Name: examen_pvmoal examen_pvmoal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmoal
    ADD CONSTRAINT examen_pvmoal_pkey PRIMARY KEY (id);


--
-- Name: examen_pvmohn examen_pvmohn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmohn
    ADD CONSTRAINT examen_pvmohn_pkey PRIMARY KEY (id);


--
-- Name: examen_pvmom examen_pvmom_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmom
    ADD CONSTRAINT examen_pvmom_pkey PRIMARY KEY (id);


--
-- Name: examen_pvmor examen_pvmor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmor
    ADD CONSTRAINT examen_pvmor_pkey PRIMARY KEY (id);


--
-- Name: examen_pvmos examen_pvmos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmos
    ADD CONSTRAINT examen_pvmos_pkey PRIMARY KEY (id);


--
-- Name: examen_pvmosol examen_pvmosol_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvmosol
    ADD CONSTRAINT examen_pvmosol_pkey PRIMARY KEY (id);


--
-- Name: examen_pvt examen_pvt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_pvt
    ADD CONSTRAINT examen_pvt_pkey PRIMARY KEY (id);


--
-- Name: examen_respirador examen_respirador_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_respirador
    ADD CONSTRAINT examen_respirador_pkey PRIMARY KEY (id);


--
-- Name: examen_salud examen_salud_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_salud
    ADD CONSTRAINT examen_salud_pkey PRIMARY KEY (id);


--
-- Name: examen_somnolencia examen_somnolencia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_somnolencia
    ADD CONSTRAINT examen_somnolencia_pkey PRIMARY KEY (id);


--
-- Name: exposicion exposicion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exposicion
    ADD CONSTRAINT exposicion_pkey PRIMARY KEY (id);


--
-- Name: factor_riesgo factor_riesgo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factor_riesgo
    ADD CONSTRAINT factor_riesgo_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: fuente_incidente fuente_incidente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fuente_incidente
    ADD CONSTRAINT fuente_incidente_pkey PRIMARY KEY (id);


--
-- Name: genero genero_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genero
    ADD CONSTRAINT genero_pkey PRIMARY KEY (id);


--
-- Name: grupo_sanguineo grupo_sanguineo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grupo_sanguineo
    ADD CONSTRAINT grupo_sanguineo_pkey PRIMARY KEY (id);


--
-- Name: headers_tables headers_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.headers_tables
    ADD CONSTRAINT headers_tables_pkey PRIMARY KEY (id);


--
-- Name: instruccion instruccion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instruccion
    ADD CONSTRAINT instruccion_pkey PRIMARY KEY (id);


--
-- Name: ley_social ley_social_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ley_social
    ADD CONSTRAINT ley_social_pkey PRIMARY KEY (id);


--
-- Name: licencia_medica licencia_medica_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.licencia_medica
    ADD CONSTRAINT licencia_medica_pkey PRIMARY KEY (id);


--
-- Name: lugar_atencion lugar_atencion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lugar_atencion
    ADD CONSTRAINT lugar_atencion_pkey PRIMARY KEY (id);


--
-- Name: medicamento medicamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicamento
    ADD CONSTRAINT medicamento_pkey PRIMARY KEY (id);


--
-- Name: medio_derivacion medio_derivacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medio_derivacion
    ADD CONSTRAINT medio_derivacion_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: modalidad modalidad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modalidad
    ADD CONSTRAINT modalidad_pkey PRIMARY KEY (id);


--
-- Name: nacionalidad nacionalidad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nacionalidad
    ADD CONSTRAINT nacionalidad_pkey PRIMARY KEY (id);


--
-- Name: nivel_riesgo nivel_riesgo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nivel_riesgo
    ADD CONSTRAINT nivel_riesgo_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: paciente paciente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paciente
    ADD CONSTRAINT paciente_pkey PRIMARY KEY (id);


--
-- Name: paciente paciente_rut_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paciente
    ADD CONSTRAINT paciente_rut_unique UNIQUE (rut);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: planta planta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.planta
    ADD CONSTRAINT planta_pkey PRIMARY KEY (id);


--
-- Name: prevision prevision_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prevision
    ADD CONSTRAINT prevision_pkey PRIMARY KEY (id);


--
-- Name: pueblo pueblo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pueblo
    ADD CONSTRAINT pueblo_pkey PRIMARY KEY (id);


--
-- Name: religion religion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.religion
    ADD CONSTRAINT religion_pkey PRIMARY KEY (id);


--
-- Name: responsable responsable_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.responsable
    ADD CONSTRAINT responsable_pkey PRIMARY KEY (id);


--
-- Name: seguro seguro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seguro
    ADD CONSTRAINT seguro_pkey PRIMARY KEY (id);


--
-- Name: semaforo semaforo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.semaforo
    ADD CONSTRAINT semaforo_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sistema_afectado sistema_afectado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sistema_afectado
    ADD CONSTRAINT sistema_afectado_pkey PRIMARY KEY (id);


--
-- Name: team_invitations team_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_invitations
    ADD CONSTRAINT team_invitations_pkey PRIMARY KEY (id);


--
-- Name: team_invitations team_invitations_team_id_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_invitations
    ADD CONSTRAINT team_invitations_team_id_email_unique UNIQUE (team_id, email);


--
-- Name: team_user team_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_user
    ADD CONSTRAINT team_user_pkey PRIMARY KEY (id);


--
-- Name: team_user team_user_team_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_user
    ADD CONSTRAINT team_user_team_id_user_id_unique UNIQUE (team_id, user_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: test_drogas test_drogas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_drogas
    ADD CONSTRAINT test_drogas_pkey PRIMARY KEY (id);


--
-- Name: tipo_accidente tipo_accidente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_accidente
    ADD CONSTRAINT tipo_accidente_pkey PRIMARY KEY (id);


--
-- Name: tipo_atencion tipo_atencion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_atencion
    ADD CONSTRAINT tipo_atencion_pkey PRIMARY KEY (id);


--
-- Name: tipo_enfermedad tipo_enfermedad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_enfermedad
    ADD CONSTRAINT tipo_enfermedad_pkey PRIMARY KEY (id);


--
-- Name: tipo_examen tipo_examen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_examen
    ADD CONSTRAINT tipo_examen_pkey PRIMARY KEY (id);


--
-- Name: tipo_licencia tipo_licencia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_licencia
    ADD CONSTRAINT tipo_licencia_pkey PRIMARY KEY (id);


--
-- Name: trastorno_cronico trastorno_cronico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trastorno_cronico
    ADD CONSTRAINT trastorno_cronico_pkey PRIMARY KEY (id);


--
-- Name: turno turno_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turno
    ADD CONSTRAINT turno_pkey PRIMARY KEY (id);


--
-- Name: unidad unidad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unidad
    ADD CONSTRAINT unidad_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_rut_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_rut_unique UNIQUE (rut);


--
-- Name: vacuna vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vacuna
    ADD CONSTRAINT vacuna_pkey PRIMARY KEY (id);


--
-- Name: notifications_notifiable_type_notifiable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_notifiable_type_notifiable_id_index ON public.notifications USING btree (notifiable_type, notifiable_id);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: teams_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX teams_user_id_index ON public.teams USING btree (user_id);


--
-- Name: examen_epo semaforo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.examen_epo
    ADD CONSTRAINT semaforo FOREIGN KEY (semaforo) REFERENCES public.semaforo(id);


--
-- Name: team_invitations team_invitations_team_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_invitations
    ADD CONSTRAINT team_invitations_team_id_foreign FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

