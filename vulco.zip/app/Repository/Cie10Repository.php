<?php

namespace App\Repository;

use App\Models\Cie10;


class Cie10Repository extends Repository
{
    public function __construct(Cie10 $model)
    {
        $this->model = $model;
    }



    // Add any necessary methods to the repository here
}
