const logo = "/build/assets/logo-HUznXB3o.jpg";
export {
  logo as l
};
//# sourceMappingURL=logo-DLUxz0ei.js.map
